package public

import "embed"

//go:embed *
var Public embed.FS
