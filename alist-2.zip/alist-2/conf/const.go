package conf

const (
	UNKNOWN = iota
	FOLDER
	OFFICE
	VIDEO
	AUDIO
	TEXT
	IMAGE
)