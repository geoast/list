package utils

import jsoniter "github.com/json-iterator/go"

var Json = jsoniter.ConfigCompatibleWithStandardLibrary
